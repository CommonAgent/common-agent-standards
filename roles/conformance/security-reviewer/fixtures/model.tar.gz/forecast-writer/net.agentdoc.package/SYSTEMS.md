# The systems this agent needs

Named by what the work needs rather than by product. The access level
is the most this work needs; a deployment that grants more is granting
more than the job requires.

| System | Kind | Access | What the access is for |
|---|---|---|---|
| text-reasoning | model | trigger | to turn the forecast figures the caller hands over into one plain sentence; the caller's material is sent to it |

Whoever deploys this agent binds these systems to their own,
and places any named credential. Nothing here names a product.
